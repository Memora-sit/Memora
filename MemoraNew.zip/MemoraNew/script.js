
// Menu mobile
const menuButton = document.querySelector(".menu-toggle");
const navigation = document.querySelector(".nav-links");

if (menuButton && navigation) {
    menuButton.addEventListener("click", () => {
        const isOpen = navigation.classList.toggle("open");

        menuButton.setAttribute("aria-expanded", String(isOpen));
        menuButton.textContent = isOpen ? "✕" : "☰";
    });
}

// Sélection des produits
const productButtons = document.querySelectorAll(".select-product");
const countElement = document.querySelector("#selected-count");
const totalElement = document.querySelector("#selected-total");

const selectedProducts = new Map();

function updateSummary() {
    let total = 0;

    selectedProducts.forEach((product) => {
        total += product.price;
    });

    if (countElement) {
        countElement.textContent = selectedProducts.size;
    }

    if (totalElement) {
        totalElement.textContent = total.toLocaleString("fr-FR", {
            minimumFractionDigits: 0,
            maximumFractionDigits: 3
        }) + " DT";
    }
}

productButtons.forEach((button, index) => {
    button.addEventListener("click", () => {
        const name = button.dataset.name;
        const price = Number(button.dataset.price);

        if (selectedProducts.has(index)) {
            selectedProducts.delete(index);
            button.classList.remove("selected");
            button.textContent = "Choisir cet article";
        } else {
            selectedProducts.set(index, { name, price });
            button.classList.add("selected");
            button.textContent = "Article sélectionné ✓";
        }

        updateSummary();
    });
});

// Formulaire de contact
const contactForm = document.querySelector("#contact-form");
const formMessage = document.querySelector("#form-message");

if (contactForm && formMessage) {
    contactForm.addEventListener("submit", (event) => {
        event.preventDefault();

        const nom = document.querySelector("#nom").value.trim();

        formMessage.textContent =
            "Bonjour " + nom +
            ", votre demande a bien été prise en compte. Merci pour votre intérêt pour Memora ♡";

        contactForm.reset();
    });
}
